import React, { useEffect, useRef, useState } from 'react';
import tabascoSvg from '../assets/Tabasco_only.svg?raw';
import { Link, useNavigate } from 'react-router-dom';
import paisajeTabasco from '../assets/paisaje_tabasco.png';
import { motion, useScroll, useTransform } from 'framer-motion';
import Confetti from 'react-confetti';
import gifVillahermosa from '../assets/Villahermosa.gif';
import logo from '../assets/Logo.png';
import { Menu } from 'lucide-react';




function MapaTabasco({ onRegresar, estado, eventos }) {
  const containerRef = useRef(null);
  const [tooltip, setTooltip] = useState({ visible: false, name: '', x: 0, y: 0 });
  const [formData, setFormData] = useState({ dias: '',tipo: '',lugarInicio: '',ultimoLugar: '',intereses: '',mes: '',email: ''});
  const [eventoIndex, setEventoIndex] = useState(0);
  const [errorEvento, setErrorEvento] = useState([]);
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [presupuestoInput, setPresupuestoInput] = useState('');
  const [mostrarZonas, setMostrarZonas] = useState(false);
  const [gifVisible, setGifVisible] = useState(false);
  const [gifPosition, setGifPosition] = useState({ x: 0, y: 0 });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [seleccionando, setSeleccionando] = useState(null);
  const [confirmacionDias, setConfirmacionDias] = useState('');
  const [tooltipSeleccion, setTooltipSeleccion] = useState('');
  const timeoutRef = useRef(null);
  const [mostrarMapaMapbox, setMostrarMapaMapbox] = useState(false);



  
  // Ref y tamaño para limitar el confeti al carrusel de eventos
  const eventsRef = useRef(null);
  const [eventsSize, setEventsSize] = useState({ width: 0, height: 0 });
   useEffect(() => {
    if (eventsRef.current) { const { width, height } = eventsRef.current.getBoundingClientRect(); setEventsSize({ width, height });}}, [mostrarZonas, eventoIndex]);
  const navigate = useNavigate();
  // Variants para slide + fade-in del mapa
  const mapVariants = { hidden: { opacity: 0, y: 20 },visible: {opacity: 1,y: 0,transition: { duration: 0.8, ease: 'easeOut' } }};
  const { scrollY } = useScroll();
  const bgY = useTransform(scrollY, [0, 300], ['0%', '20%']);
  const zonasVillahermosa = [
    {
      nombre: 'Centro Histórico / Zona Luz',
      descripcion: 'Casco antiguo con plazas, catedral, arquitectura colonial y ambiente cultural.'
    },
    {
      nombre: 'Paseo Tabasco',
      descripcion: 'Avenida principal con monumentos, tiendas y vida urbana activa.'
    },
    {
      nombre: 'Parque Tomás Garrido y Laguna de las Ilusiones',
      descripcion: 'Espacio natural con malecón, teatro al aire libre, laguna y senderos.'
    },
    {
      nombre: 'Tabasco 2000',
      descripcion: 'Zona moderna con centros comerciales, oficinas, hoteles y bancos.'
    },
    {
      nombre: 'Yumká',
      descripcion: 'Reserva ecológica con animales, selva y educación ambiental.'
    },
    {
      nombre: 'Museo Carlos Pellicer',
      descripcion: 'Museo de antropología con piezas olmecas y mayas.'
    },
    {
      nombre: 'Museo Papagayo',
      descripcion: 'Museo interactivo ideal para familias y niños con juegos educativos.'
    }
  ];
  

useEffect(() => {
  if (containerRef.current) {
    containerRef.current.innerHTML = tabascoSvg;
    const svg = containerRef.current.querySelector('svg');
    if (svg) {
      svg.setAttribute('width', '100%');
      svg.setAttribute('height', '100%');
      svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      svg.style.display = 'block';

      // Agregar filtro de sombra opcional (puedes quitarlo si solo quieres el borde)
      if (!svg.querySelector('defs')) {
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        defs.innerHTML = `
          <filter id="bordeConSombra" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="0" stdDeviation="1.2" flood-color="black" flood-opacity="0.5"/>
          </filter>
        `;
        svg.prepend(defs);
      }
    }

    const paths = containerRef.current.querySelectorAll('path');
paths.forEach((path, index) => {
  const titleTag = path.querySelector("title");
  let name = "Municipio";
  if (titleTag) {
    name = titleTag.textContent;
  }

  // Tooltip y eventos
path.addEventListener("mouseenter", e => {
  // Calcula posición RELATIVA al contenedor del mapa
  const containerRect = containerRef.current.getBoundingClientRect();
  const relX = e.clientX - containerRect.left;
  const relY = e.clientY - containerRect.top;
  setTooltip({ visible: true, name, x: relX, y: relY });
  if (name.toLowerCase().includes("centro") || name.toLowerCase().includes("villahermosa")) {
    setGifVisible(true);
    setGifPosition({ x: relX, y: relY });
  }
});


  path.addEventListener("mouseleave", () => {
    setTooltip({ visible: false, name: "", x: 0, y: 0 });
    setGifVisible(false);
  });
path.addEventListener("click", () => {
  // Captura el valor más reciente de seleccionando
  const seleccion = document.body.getAttribute("data-seleccionando");

  if (seleccion === 'inicio') {
    setFormData(prev => ({ ...prev, lugarInicio: name }));
    setSeleccionando(null);
    document.body.removeAttribute("data-seleccionando");
  } else if (seleccion === 'fin') {
    setFormData(prev => ({ ...prev, ultimoLugar: name }));
    setSeleccionando(null);
    document.body.removeAttribute("data-seleccionando");
  }
});



  if (titleTag) {
    titleTag.remove();
  }

    // 🔲 Bordeado personalizado
  path.setAttribute('stroke', '#000000');          // color negro
  path.setAttribute('stroke-width', '2');          // grosor del borde
  path.setAttribute('stroke-linejoin', 'round');   // esquinas suaves
  // path.setAttribute('filter', 'url(#bordeConSombra)'); // activar para sombras
});
  }
}, []);


return (
  <>
    {/* HEADER */}
    <header className="sticky top-0 z-50 w-full py-4 px-6 flex justify-between items-center bg-[var(--color-primary)] shadow-md">
      <div className="flex items-center gap-4">
        <img src={logo} alt="Logo" className="h-10 sm:h-12 w-auto" />
        <h1 className="text-2xl sm:text-4xl font-extrabold tracking-wide drop-shadow-md text-black">
          Pueblos de Ensueño
        </h1>
      </div>
      <nav className="hidden md:flex gap-3 lg:gap-5 items-center">
        {['/puntos-cercanos','/mapa','/InterestsSelector','/login'].map((path, i) => (
          <Link key={i} to={path}>
            <button className="px-4 py-2 bg-[var(--color-tertiary)] hover:bg-[var(--color-secondary)] rounded-lg font-semibold transition">
              {['Puntos cercanos','Mapa Interactivo','Invitado','Iniciar sesión'][i]}
            </button>
          </Link>
        ))}
        <Link to="/">
          <button className="px-4 py-2 bg-[var(--color-tertiary)] hover:bg-[var(--color-secondary)] rounded-lg font-semibold transition">
            Ir al Home
          </button>
        </Link>
      </nav>
      <button className="block md:hidden text-gray-800" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
        <Menu size={24} />
      </button>
    </header>
    {/* NAV MOBILE */}
    {mobileMenuOpen && (
      <nav className="md:hidden bg-[var(--color-tertiary)] shadow-md px-6 py-4 space-y-2">
        {['/puntos-cercanos','/mapa','/InterestsSelector','/login'].map((path, i) => (
          <Link key={i} to={path}>
            <button className="w-full px-4 py-2 bg-[var(--color-tertiary)] hover:bg-[var(--color-secondary)] rounded-lg font-semibold transition">
              {['Puntos cercanos','Mapa Interactivo','Invitado','Iniciar sesión'][i]}
            </button>
          </Link>
        ))}
        <Link to="/">
          <button className="w-full px-4 py-2 bg-[var(--color-tertiary)] hover:bg-[var(--color-secondary)] rounded-lg font-semibold transition">
            Ir al Home
          </button>
        </Link>
      </nav>
    )}

    {/* CONTENIDO PRINCIPAL */}
    <div
      className="relative min-h-screen p-6 overflow-hidden text-gray-800 bg-gradient-to-b from-[var(--color-cuatro)] to-[var(--color-verde)] bg-cover bg-center transition-all duration-300 ease-in-out"
      style={{
        backgroundImage: `url(${paisajeTabasco})`,
        backgroundPosition: `center ${bgY}`,
        backgroundSize: 'cover'
      }}
    >
      <div className="relative z-10">
        <div className="absolute top-[60%] left-1/3 transform -translate-x-1/2 -translate-y-1/2 w-[95%] sm:w-[80%] lg:w-[70%] h-[65vh] sm:h-[75vh] lg:h-[80vh] max-w-screen-lg px-4 sm:px-6 lg:px-8">
 <motion.div>
  <div
  
    ref={containerRef}
    className="w-full h-full [&>svg]:w-full [&>svg]:h-full [&>svg]:object-contain relative"
    
  >
    {/* Inserta aquí el tooltip y el gif */}
    {tooltipSeleccion && (
  <div className="absolute top-4 right-4 z-50 bg-white/90 text-blue-900 text-sm font-medium px-4 py-2 rounded-xl shadow-lg border border-blue-300 animate-fade-in pointer-events-none">
    {tooltipSeleccion}
  </div>
)}

    {tooltip.visible && (
      <div
        className="absolute z-50 bg-yellow-200 text-gray-800 text-sm font-bold px-4 py-2 rounded-xl shadow-lg border-2 border-amber-300 animate-fade-in pointer-events-none"
        style={{
          top: tooltip.y + 24,
          left: tooltip.x + 24,
        }}
      >
        🌸 {tooltip.name}
      </div>
    )}
    {gifVisible && (
      <img
        src={gifVillahermosa}
        alt="Villahermosa"
        className="absolute z-40 w-52 rounded-xl shadow-lg border-4 border-white pointer-events-none animate-fade-in"
        style={{
          top: gifPosition.y + 40,
          left: gifPosition.x + 40,
        }}
      />
    )}
  </div>
</motion.div>

        </div>
        <div className="w-full max-w-screen-xl mx-auto grid grid-cols-1 xl:grid-cols-[1fr_400px_1fr] gap-6 px-4 md:px-6 xl:px-8 items-start">
          <div className={`w-full xl:w-[360px]  h-[750px] overflow-y-auto bg-white/80 rounded-2xl shadow-xl p-6 border-4 relative flex flex-col col-start-3  ${mostrarZonas ? 'border-yellow-300' : 'border-teal-300'}`}>

<form
  onSubmit={(e) => {
    e.preventDefault();
const errores = [];

if (!formData.lugarInicio) errores.push("📍 Falta seleccionar el lugar de inicio");
if (!formData.ultimoLugar) errores.push("🏁 Falta seleccionar el último lugar");
if (!formData.dias) errores.push("📅 Indica los días de viaje");
if (!formData.tipo) errores.push("💰 Elige un presupuesto estimado");

if (errores.length > 0) {
  setErrorEvento(errores);
  return;
}

    setErrorEvento(false);
navigate("/itinerario", {
  state: {
    estado,
    dias: `${fechaInicio} a ${fechaFin}`,
    presupuesto: formData.tipo, // ← usa formData.tipo también aquí
    eventosSeleccionados: [{
      nombre: formData.tipo,
      icono: "🎯",
      fechas: `${fechaInicio} a ${fechaFin}`,
      elementos: formData.intereses || '',
      actividades: `Desde ${formData.lugarInicio} hasta ${formData.ultimoLugar}`,
    }],
    email: formData.email,
  },
});

  }}
  className="flex flex-col gap-4 text-sm"
>
  <label className="font-bold text-lg text-center">🐯 ITINERARIOS DE VIAJE</label>

{/* Lugar de inicio */}
<button
  type="button"
onClick={() => {
  setSeleccionando('inicio');
  document.body.setAttribute("data-seleccionando", "inicio");

  if (timeoutRef.current) clearTimeout(timeoutRef.current);
  setTooltipSeleccion("🖱 Haz clic en el mapa para elegir tu primera parada");
  timeoutRef.current = setTimeout(() => setTooltipSeleccion(''), 3000);
}}

  className="w-full border border-blue-300 rounded-full px-4 py-2 bg-blue-100 hover:bg-blue-200 transition text-left"
>
  {formData.lugarInicio || 'Seleccionar municipio...'}
</button>



{/* Último lugar */}
<button
  type="button"
onClick={() => {
  setSeleccionando('fin');
  document.body.setAttribute("data-seleccionando", "fin");

  if (timeoutRef.current) clearTimeout(timeoutRef.current);
  setTooltipSeleccion("🖱 Haz clic en el mapa para elegir tu última parada");
  timeoutRef.current = setTimeout(() => setTooltipSeleccion(''), 3000);
}}

  className="w-full border border-green-300 rounded-full px-4 py-2 bg-green-100 hover:bg-green-200 transition text-left"
>
  {formData.ultimoLugar || 'Seleccionar municipio...'}
</button>





<div className="flex flex-col gap-2">
  <label className="block text-sm font-medium text-gray-800">📅 Días de viaje</label>

  <div className="flex items-center gap-2">
    <button
      type="button"
      onClick={() => {
        const actual = parseInt(formData.dias || "1");
        if (actual > 1) {
          setFormData({ ...formData, dias: String(actual - 1) });
        }
      }}
      className="px-3 py-1 bg-gray-200 rounded-full text-lg font-bold hover:bg-gray-300"
    >
      −
    </button>

    <input
      type="text"
      inputMode="numeric"
      pattern="[0-9]*"
      value={formData.dias || ''}
      onChange={(e) => {
        const val = e.target.value.replace(/\D/g, ""); // Elimina todo lo que no sea número
        const num = parseInt(val);
        if (!isNaN(num) && num > 0 && num <= 30) {
          setFormData({ ...formData, dias: String(num) });
        } else if (val === "") {
          setFormData({ ...formData, dias: "" });
        }
      }}
      placeholder="1"
      className="w-24 text-center border border-gray-300 rounded-full px-4 py-2"
    />

    <button
      type="button"
      onClick={() => {
        const actual = parseInt(formData.dias || "1");
        if (actual < 30) {
          setFormData({ ...formData, dias: String(actual + 1) });
        }
      }}
      className="px-3 py-1 bg-gray-200 rounded-full text-lg font-bold hover:bg-gray-300"
    >
      +
    </button>

<button
  type="button"
  onClick={() => {
    if (formData.dias && parseInt(formData.dias) > 0 && parseInt(formData.dias) <= 30) {
      setConfirmacionDias(`✅ Se han seleccionado ${formData.dias} día${formData.dias === "1" ? '' : 's'} de viaje`);
      setTimeout(() => setConfirmacionDias(''), 3000); // Oculta después de 3s
    } else {
      setConfirmacionDias("⚠️ Ingrese un número válido entre 1 y 30");
      setTimeout(() => setConfirmacionDias(''), 3000);
    }
  }}
  className="ml-2 bg-yellow-400 text-black font-bold px-4 py-2 rounded-full hover:bg-yellow-500"
>
  OK
</button>



  </div>
  {confirmacionDias && (
  <div className="mt-2 p-3 border-l-4 border-green-500 bg-green-100 text-green-800 rounded-md shadow-sm text-sm font-medium">
    {confirmacionDias}
  </div>
)}
</div>


<select
  value={formData.tipo || ''}
  onChange={e => setFormData({ ...formData, tipo: e.target.value })}
  className="w-full border border-gray-300 rounded-full px-4 py-2 bg-white"
  required
>
  <option value="" disabled>💰 Presupuesto estimado</option>
  <option value="Económico">💸 Económico (hasta $1,000 MXN por día)</option>
  <option value="Moderado">💼 Moderado ($1,000 – $2,000 MXN por día)</option>
  <option value="Confort">🏨 Confort ($2,000 – $4,000 MXN por día)</option>
  <option value="Lujo">💎 Lujo total (más de $4,000 MXN por día)</option>
</select>


<select
  value={formData.mes || ''}
  onChange={e => setFormData({ ...formData, mes: e.target.value })}
  className="w-full border border-gray-300 rounded-full px-4 py-2 bg-white"
  required
>
  <option value="" disabled>📆 Selecciona un mes</option>
  <option value="Enero">Enero</option>
  <option value="Febrero">Febrero</option>
  <option value="Marzo">Marzo</option>
  <option value="Abril">Abril</option>
  <option value="Mayo">Mayo</option>
  <option value="Junio">Junio</option>
  <option value="Julio">Julio</option>
  <option value="Agosto">Agosto</option>
  <option value="Septiembre">Septiembre</option>
  <option value="Octubre">Octubre</option>
  <option value="Noviembre">Noviembre</option>
  <option value="Diciembre">Diciembre</option>
</select>


<select
  value=""
  onChange={(e) => {
    const valor = e.target.value;
    if (valor === 'Cerrar') {
      setFormData({ ...formData, intereses: '' });
    } else {
      const actuales = formData.intereses?.split(', ').filter(Boolean) || [];
      if (!actuales.includes(valor)) {
        const nuevos = [...actuales, valor];
        setFormData({ ...formData, intereses: nuevos.join(', ') });
      }
    }
  }}
  className="w-full border border-gray-300 rounded-full px-4 py-2 bg-white"
>
  <option value="" disabled>🎯 Intereses</option>
  <option value="Naturaleza">Naturaleza</option>
  <option value="Compras">Compras</option>
  <option value="Arte">Arte</option>
  <option value="Museos">Museos</option>
  <option value="Gastronomía">Gastronomía</option>
  <option value="Aventura">Aventura</option>
  <option value="Acceso gratuito">Acceso gratuito</option>
  <option value="Cerrar" className="text-red-500">Cerrar</option>
</select>
{formData.intereses && formData.intereses.split(', ').length > 0 && (
  <div className="flex flex-wrap gap-2 mt-2">
    {formData.intereses.split(', ').map((interes, idx) => (
      <span
        key={idx}
        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full flex items-center gap-2"
      >
        {interes}
        <button
          type="button"
          onClick={() => {
            const restantes = formData.intereses
              .split(', ')
              .filter((i) => i !== interes);
            setFormData({
              ...formData,
              intereses: restantes.join(', ')
            });
          }}
          className="text-red-500 hover:text-red-700 font-bold"
        >
          ✕
        </button>
      </span>
    ))}
  </div>
)}



  {/* Campos de fecha existentes */}
  <div className="flex flex-col gap-2">
    <label className="block text-sm font-medium text-gray-800">Fechas de viaje</label>
    <div className="flex flex-col sm:flex-row items-center gap-2 w-full">
      <input
        type="date"
        min="2025-08-06"
        value={fechaInicio}
        onChange={e => {
          setFechaInicio(e.target.value);
          setFechaFin('');
        }}
        className="w-full sm:w-[48%] border border-amber-300 rounded px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        required
      />
      <span className="text-gray-600">→</span>
      <input
        type="date"
        min={fechaInicio}
        max="2025-09-05"
        value={fechaFin}
        onChange={e => setFechaFin(e.target.value)}
        disabled={!fechaInicio}
        className="w-full sm:w-[48%] border border-amber-300 rounded px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-400 disabled:bg-gray-100"
        required
      />
    </div>
  </div>

  <div className="flex justify-between items-center mt-4">
    <button
      type="button"
      onClick={onRegresar}
      className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-200"
    >
      Regresar
    </button>
    <button
      type="submit"
      className="bg-yellow-400 text-black font-bold px-6 py-2 rounded-full hover:bg-yellow-500"
    >
      CREAR
    </button>
  </div>

  <Link
    to="/productos-tabasco"
    className="mt-4 inline-block text-center bg-pink-200 text-gray-900 px-4 py-2 rounded-lg shadow hover:bg-pink-300 transition"
  >
    Ver productos artesanales de Tabasco
  </Link>

  <div className="flex justify-center gap-4 mt-4 text-xl text-gray-600">
    <i className="fab fa-facebook-square" />
    <i className="fab fa-twitter" />
    <i className="fab fa-instagram" />
    <i className="far fa-envelope" />
  </div>
</form>
          </div>
        </div>
      </div>
    </div>    
    </>
  );

}

export default MapaTabasco;
