import { useEffect, useRef, useState } from 'react';
import svgUrl from '../assets/MexicoSvg.svg?url';
import MapaTabasco from './MapaTabasco';


function MapaMexico() {
  const containerRef = useRef(null);
  const [tooltip, setTooltip] = useState({ visible: false, name: '', x: 0, y: 0 });
  const [estadoSeleccionado, setEstadoSeleccionado] = useState(null);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [formData, setFormData] = useState({ dias: '', presupuesto: '', evento: '' });
  const [eventoIndex, setEventoIndex] = useState(0);
  const [errorEvento, setErrorEvento] = useState(false);


  const eventosPorEstado = {
  Tabasco: [
    {
      nombre: "Feria Tabasco 2025",
      fechas: "Del 27 de abril al 12 de mayo",
      descripcion: "La Feria Tabasco es una celebración tradicional que destaca la identidad y cultura del estado.",
      elementos: "Música, gastronomía, trajes típicos",
      actividades: "Desfiles, juegos mecánicos, pabellones culturales",
      icono: "🎉",
    },
    {
      nombre: "Festival del Cacao",
      fechas: "Del 15 al 20 de junio",
      descripcion: "Celebración del cacao tabasqueño con talleres, catas y recorridos por fincas.",
      elementos: "Chocolate artesanal, danza, historia",
      actividades: "Talleres de chocolate, visitas guiadas",
      icono: "🍫",
    },
    {
      nombre: "Carnaval de Villahermosa",
      fechas: "Febrero 2025",
      descripcion: "Colorido carnaval con desfiles, música y reinas de belleza regional.",
      elementos: "Danza, folclor, cultura popular",
      actividades: "Desfiles, comparsas, conciertos",
      icono: "🎭",
    },
  ],
};




useEffect(() => {
  fetch(svgUrl)
    .then((res) => res.text())
    .then((svg) => {
      if (containerRef.current) {
        containerRef.current.innerHTML = svg;

        const paths = containerRef.current.querySelectorAll('path.hoverable-state');
        paths.forEach(path => {
          const title = path.querySelector('title')?.textContent;
          path.addEventListener('mouseenter', e => {
            setTooltip({ visible: true, name: title, x: e.clientX, y: e.clientY });
          });
          path.addEventListener('mouseleave', () => {
            setTooltip({ visible: false, name: '', x: 0, y: 0 });
          });
          path.addEventListener('click', () => {
            setEstadoSeleccionado(title); // Nuevo
            setMostrarFormulario(true);   // Nuevo
          });
        });
      }
    });
}, []);


  return (
    <div className="min-h-screen w-screen bg-gradient-to-br from-yellow-200 via-rose-200 to-pink-100">
      {/* Franja decorativa */}
      <div className="w-full flex justify-center bg-yellow-300 py-1 shadow-md">
        <svg className="h-6 w-full" viewBox="0 0 100 20" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 0 Q 2.5 20, 5 0 ... 100 0" fill="#f59e0b" />
        </svg>
      </div>

      {/* Encabezado */}
      <header className="bg-pink-600 text-white py-4 px-6 shadow-md text-center w-full">
        <h1 className="text-3xl font-extrabold tracking-wide uppercase">Pueblos de ensueño</h1>
        <p className="text-sm mt-1">Explora la riqueza cultural de México</p>
      </header>

      {/* Botones */}
      <nav className="flex justify-center gap-4 mt-4 w-full">
        <a href="/login" className="bg-yellow-400 text-black px-4 py-1 rounded-full shadow hover:bg-yellow-300 transition">Login</a>
        <a href="/register" className="bg-orange-400 text-white px-4 py-1 rounded-full shadow hover:bg-orange-300 transition">Registro</a>
      </nav>

      {/* Mapa */}
      <section className="mt-6 px-4 py-4 bg-white/80 shadow-xl rounded-2xl border-2 border-pink-200 max-w-[700px] mx-auto">
        <h2 className="text-center text-xl font-bold text-pink-600 mb-4">Mapa Interactivo</h2>

        <div className="flex justify-center items-center min-h-[300px] relative">
          <div
            ref={containerRef}
            className="w-full [&>svg]:w-full [&>svg]:h-auto [&>svg]:mx-auto [&>svg]:block"
          />

          {/* Tooltip personalizado */}
{tooltip.visible && (
  <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-yellow-300 text-pink-800 text-sm font-bold px-4 py-2 rounded-xl shadow-lg border-2 border-pink-500 animate-fade-in z-50 flex items-center gap-2">
    <span className="text-lg">🌸</span>
    <span>{tooltip.name}</span>
  </div>
)}


        </div>
        {mostrarFormulario && (
  <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
    <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md border-4 border-pink-400">
      <h3 className="text-xl font-bold text-pink-700 mb-2">Itinerario en {estadoSeleccionado}</h3>
<form
onSubmit={(e) => {
  e.preventDefault();
  if (!formData.evento) {
    setErrorEvento(true);
    return;
  }
  setErrorEvento(false);
localStorage.setItem(
  "itinerarioData",
  JSON.stringify({
    estado: estadoSeleccionado,
    dias: formData.dias,
    presupuesto: formData.presupuesto,
    evento: formData.evento
  })
);
  setMostrarFormulario(false);
  window.location.href = "/itinerario";
}}

  className="flex flex-col gap-6 w-full max-w-lg mx-auto animate-fade-in-up"
>
  {/* Entradas del usuario */}
  <div className="flex flex-col gap-4">
    <div>
      <label className="block text-sm font-medium text-pink-700">Días de viaje</label>
      <input
        type="number"
        min={1}
        required
        value={formData.dias}
        onChange={(e) => setFormData({ ...formData, dias: e.target.value })}
        className="w-full border border-pink-300 rounded px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-pink-400"
      />
    </div>
    <div>
      <label className="block text-sm font-medium text-pink-700">Presupuesto (MXN)</label>
      <input
        type="number"
        min={0}
        required
        value={formData.presupuesto}
        onChange={(e) => setFormData({ ...formData, presupuesto: e.target.value })}
        className="w-full border border-pink-300 rounded px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-pink-400"
      />
    </div>
  </div>

  {/* Carrusel de eventos */}
  <div className="flex flex-col items-center gap-4 w-full">
    {eventosPorEstado[estadoSeleccionado]?.length > 0 && (
      <>
        <div className="bg-yellow-100 border-2 border-pink-500 rounded-xl p-4 shadow-lg w-full">
          {(() => {
            const evento = eventosPorEstado[estadoSeleccionado][eventoIndex];
            return (
              <div className="flex flex-col gap-2">
                <h4 className="text-lg font-extrabold text-pink-700">
                  {evento.icono} {evento.nombre}
                </h4>
                <p className="text-sm text-gray-700">
                  <strong>{evento.fechas}</strong>
                </p>
                <p className="text-sm text-gray-700">{evento.descripcion}</p>
                <div className="text-sm text-gray-700">
                  <p><strong>Elementos culturales:</strong> {evento.elementos}</p>
                  <p><strong>Actividades destacadas:</strong> {evento.actividades}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, evento: evento.nombre })}
                  className="mt-2 bg-pink-600 text-white px-4 py-2 rounded-full hover:bg-pink-500 transition"
                >
                  Agregar a mi itinerario
                </button>
                {formData.evento === evento.nombre && (
                  <p className="text-green-700 font-semibold mt-2">
                    ✅ Evento seleccionado
                  </p>
                )}
                {errorEvento && (
  <p className="text-red-600 text-sm mt-2">
    ⚠️ Debes seleccionar un evento antes de continuar.
  </p>
)}
              </div>
            );
          })()}
        </div>

        {/* Navegación de eventos */}
        <div className="flex justify-center gap-4">
          <button
            type="button"
            disabled={eventoIndex === 0}
            onClick={() => setEventoIndex((prev) => prev - 1)}
            className={`px-4 py-2 rounded font-semibold transition ${
              eventoIndex === 0
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-pink-400 text-white hover:bg-pink-500"
            }`}
          >
            ◀ Anterior
          </button>
          <button
            type="button"
            disabled={eventoIndex === eventosPorEstado[estadoSeleccionado].length - 1}
            onClick={() => setEventoIndex((prev) => prev + 1)}
            className={`px-4 py-2 rounded font-semibold transition ${
              eventoIndex === eventosPorEstado[estadoSeleccionado].length - 1
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-pink-400 text-white hover:bg-pink-500"
            }`}
          >
            Siguiente ▶
          </button>
        </div>
      </>
    )}
  </div>

  {/* Botones del formulario */}
  <div className="flex justify-end gap-3 mt-4">
    <button
      type="button"
      onClick={() => setMostrarFormulario(false)}
      className="bg-gray-300 text-black px-4 py-2 rounded hover:bg-gray-200"
    >
      Cancelar
    </button>
    <button
      type="submit"
      className="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-500"
    >
      Generar itinerario
    </button>
  </div>
</form>




    </div>
  </div>
)}

      </section>

      {/* Footer */}
      <footer className="mt-6 text-center text-xs text-gray-500 pb-2 w-full">
        © 2025 Pueblos de ensueño - Colores y Cultura para el Mundo
      </footer>
    </div>
  );
}

export default MapaMexico;
