import React, { useEffect, useRef, useState } from 'react';
import tabascoSvg from '../assets/Tabasco_only.svg?raw';

function MapaTabasco({ onRegresar }) {
  const containerRef = useRef(null);
  const [tooltip, setTooltip] = useState({ visible: false, name: '', x: 0, y: 0 });

useEffect(() => {
  if (containerRef.current) {
    containerRef.current.innerHTML = tabascoSvg;

    const svg = containerRef.current.querySelector('svg');
    if (svg) {
      svg.setAttribute("width", "100%");
      svg.setAttribute("height", "100%");
      svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
      svg.style.display = "block";
    }

    const paths = containerRef.current.querySelectorAll('path');

    paths.forEach(path => {
      const titleTag = path.previousElementSibling?.tagName === 'title'
        ? path.previousElementSibling
        : path.querySelector('title');

      const name = titleTag?.textContent || 'Municipio';

      path.style.cursor = 'pointer';

      path.addEventListener('mouseenter', (e) => {
        setTooltip({
          visible: true,
          name,
          x: e.clientX,
          y: e.clientY,
        });
      });

      path.addEventListener('mouseleave', () => {
        setTooltip({ visible: false, name: '', x: 0, y: 0 });
      });

      path.addEventListener('click', () => {
        alert(`¡Haz hecho clic en ${name}!`);
      });
    });
  }
}, []);



  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-yellow-200 via-rose-200 to-pink-100 text-center p-6">
      <h2 className="text-3xl font-extrabold text-pink-700 mb-6">Estado de Tabasco</h2>

      <div
        ref={containerRef}
        className="w-[600px] h-[600px] border-4 border-pink-300 rounded-3xl shadow-xl bg-white p-6"
      />

      {tooltip.visible && (
        <div
          className="absolute z-50 bg-yellow-300 text-pink-800 text-sm font-bold px-4 py-2 rounded-xl shadow-lg border-2 border-pink-500 animate-fade-in"
          style={{ top: tooltip.y - 90, left: tooltip.x - 60 }}
        >
          🌸 {tooltip.name}
        </div>
      )}

      <button
        onClick={onRegresar}
        className="mt-8 px-6 py-3 bg-green-600 text-white rounded-full font-bold text-sm shadow-lg hover:bg-green-700 transition"
      >
        Regresar al Mapa de México
      </button>
    </div>
  );
}

export default MapaTabasco;
